[v1.0]

+ Initial Pack as of 12/2/23