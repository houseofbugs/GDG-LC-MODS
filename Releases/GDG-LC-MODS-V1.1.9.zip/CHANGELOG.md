[v1.1.9]

+ Changed Game Master Max Buy Rate to 1.0 from 1.5
+ Added OrtonLongGaming-FreddyBracken-1.0.6

[v1.1.8]

+ Added RugbugRedfern-Skinwalkers-2.0.1

[v1.1.7]

+ Added MegaPiggy-BuyableShotgun-1.0.0
+ Added MegaPiggy-BuyableShotgunShells-1.0.1
+ Updated Sligili-More_Emotes-1.2.2

[v1.1.6]

+ Added boring-InfiniteShotgunAmmo-1.0.3
+ Added x753-Mimics-2.3.0
+ Updated anormaltwig-LateCompany-1.0.7
+ Updated Renegades-FlashlightToggle-1.5.0
+ Updated FlipMods-HotbarPlus-1.3.5
+ Updated Sligili-More_Emotes-1.2.2

[v1.1.5]

+ Updated Hotbar to 1.3.4 and updated its config to new format

[v1.1.4]

+ Added gamendegamer-Lethal_Admin-1.0.6
+ Updated Hotbarplus to 1.3.3

[v1.1.3]

+ Removed malco-Lategame_Upgrades-2.6.1 Due to bugs

[v1.1.2]

+ Fixed README

[v1.1.1]

+ Added sunnobunno-YippeeMod-1.2.2
+ Added sunnobunno-LandMineFartReverb-1.0.2
+ Added Sligili-More_Emotes-1.2.1

[v1.1.0]

+ Support for v45
+ Add malco-Lategame_Upgrades-2.6.1
+ Update Morecompany to 1.0.7
+ Update LateCompany to 1.0.6

[v1.0.14]

+ Add ship loot back in

[v1.0.13]

+ Update additional suits to 1.1.0

[v1.0.12]

+ Removed old config files

[v1.0.11]

+ Updated mods to the new versions and removed ones that were causing issues.

[v1.0.10]

+ Added JT-LC_Better_Teleport-1.0.0

[v1.0.9]

+ Added FlipMods-LetMeLookDown-1.0.1

[v1.0.8]

+ Remove Radsi2-Shotgun-1.0.0 as it does nothing.

[v1.0.7]

+ Added
	+ Radsi2-Shotgun-1.0.0
	+ MetalPipeSFX-HornMoan-2.0.0
	+ sunnobunno-BonkHitSFX-1.0.1
	+ sunnobunno-LandMineFartReverb-1.0.1

[v1.0.6]

+ Remove BepInEx-BepInExPack, Evaisa-HookGenPatcher, & Evaisa-LethalLib. Let the mods that need them install them.
 

[v1.0.5]

+ Added NotAtomicBomb-Terminal_Clock-1.0.2

[v1.0.4]

+ Hotkey Setup
	+ F1 Emote
	+ F2 Point
	+ F3 MiniMap Menu
	+ F4 Toggle MiniMap
	+ F5 Override Ship Controls
	+ F6 Switch MiniMap Focus
	+ 1-8 Inventory Controls

[v1.0.3]

+ Added tinyhoot-ShipLoot-1.0.0
+ Added Pooble-LCBetterSaves-1.4.0
 
[v1.0.2]

+ Fixed Upload of 1.0.1

[v1.0.1]

+ Added mod base CFGs

[v1.0.0]

+ Initial Pack as of 12/2/23