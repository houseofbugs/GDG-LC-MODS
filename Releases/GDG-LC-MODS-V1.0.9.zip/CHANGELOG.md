[v1.0.9]

+ Added FlipMods-LetMeLookDown-1.0.1

[v1.0.8]

+ Remove Radsi2-Shotgun-1.0.0 as it does nothing.

[v1.0.7]

+ Added
	+ Radsi2-Shotgun-1.0.0
	+ MetalPipeSFX-HornMoan-2.0.0
	+ sunnobunno-BonkHitSFX-1.0.1
	+ sunnobunno-LandMineFartReverb-1.0.1

[v1.0.6]

+ Remove BepInEx-BepInExPack, Evaisa-HookGenPatcher, & Evaisa-LethalLib. Let the mods that need them install them.
 

[v1.0.5]

+ Added NotAtomicBomb-Terminal_Clock-1.0.2

[v1.0.4]

+ Hotkey Setup
	+ F1 Emote
	+ F2 Point
	+ F3 MiniMap Menu
	+ F4 Toggle MiniMap
	+ F5 Override Ship Controls
	+ F6 Switch MiniMap Focus
	+ 1-8 Inventory Controls

[v1.0.3]

+ Added tinyhoot-ShipLoot-1.0.0
+ Added Pooble-LCBetterSaves-1.4.0
 
[v1.0.2]

+ Fixed Upload of 1.0.1

[v1.0.1]

+ Added mod base CFGs

[v1.0.0]

+ Initial Pack as of 12/2/23