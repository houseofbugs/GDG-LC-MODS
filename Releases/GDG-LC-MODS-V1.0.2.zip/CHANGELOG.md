[v1.0.2]

+ Fixed Upload of 1.0.1

[v1.0.1]

+ Added mod base CFGs

[v1.0.0]

+ Initial Pack as of 12/2/23